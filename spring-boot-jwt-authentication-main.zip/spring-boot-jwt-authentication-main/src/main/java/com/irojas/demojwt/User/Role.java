package com.irojas.demojwt.User;

public enum Role {
    ADMIN,
    USER  
}
